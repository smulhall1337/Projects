import java.util.ArrayList;
import java.util.Comparator;

/**
 * This will provide the interface for the sorting methods.
 * 
 * @author Brandon Dixon
 * @version 3/9/15
 */
public interface Sorter<T>
{
    /**
     * Sorts the list in non-decreasing order, per the given comparator
     * @param list       a list
     * @param comp  a comparator of the objects in the list
     */
    public void sort(ArrayList<T> mArray, Comparator<T> c);
}
