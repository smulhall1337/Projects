import java.util.ArrayList;
import java.util.Comparator;

/**
 * This will sort an array using the bubble (sink) method.  It uses the Sorter interface.
 * 
 * @author Brandon Dixon
 * @version 3/9/15
 */
public class Bubble<T> implements Sorter<T>
{
    /**
     * Sorts the list in non-decreasing order, per the given comparator
     * @param list       a list
     * @param comp  a comparator of the objects in the list
     */
    public void sort(ArrayList<T> mArray, Comparator<T> c) {
        int scanRange = mArray.size();
        T temp;

        for (int j=0; j<mArray.size(); j++) {
            //swap all numbers in the scan range
            for (int i=1; i<scanRange; i++) {
                if (c.compare(mArray.get(i-1),mArray.get(i))>0)  {
                    temp = mArray.get(i-1);
                    mArray.set(i-1,mArray.get(i));
                    mArray.set(i,temp);
                }
            }
            scanRange--;
        }
    }
}
