import java.util.Comparator;

/**
 * This class will compare two integers
 * 
 * @author Brandon Dixon
 * @version 3/9/15
 */
public class IntegerComparator implements Comparator<Integer>
{
    public int compare(Integer o1, Integer o2) {
       if (o1<o2) return -1;
       if (o1==o2) return 0;
       
      return 1;
    }
}
