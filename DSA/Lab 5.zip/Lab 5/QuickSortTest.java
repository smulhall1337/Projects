

import static org.junit.Assert.*;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import java.util.ArrayList;
import java.util.Comparator;

/**
 * The test class SelectionTest.  This will make sure the method works correctly by testing known ArrayLists
 *
 * @author  Brandon Dixon
 * @version 3/9/15
 */
public class QuickSortTest
{
    /**
     * Default constructor for test class SelectionTest
     */
    public QuickSortTest()
    {
    }

    /**
     * Sets up the test fixture.
     *
     * Called before every test case method.
     */
    @Before
    public void setUp()
    {
    }
    
    /**
     * Test the sorting method
     */
    @Test
    public void testSelection() {
        ArrayList<Integer> test = new ArrayList<Integer>();
        test.add(7);
        test.add(4);
        test.add(12);
        test.add(-17);
        test.add(1);
        test.add(500);
        test.add(4);
        test.add(13);
        
        
        QuickSort quick = new QuickSort();
        IntegerComparator ic = new IntegerComparator();
        
        quick.sort(test,ic);
        
        System.out.println("Quick Sort:");
        for (int i=0; i<test.size(); i++) {
            System.out.println(test.get(i));
        }
        System.out.println();
    }

    /**
     * Tears down the test fixture.
     *
     * Called after every test case method.
     */
    @After
    public void tearDown()
    {
    }
}
