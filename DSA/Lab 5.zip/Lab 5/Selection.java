import java.util.ArrayList;
import java.util.Comparator;

/**
 * This will sort an ArrayList in non-decreasing order using the selection sort method.  It uses the Sorter interface.
 * 
 * @author Brandon Dixon
 * @version 3/9/15
 */
public class Selection<T> implements Sorter<T>
{
    /**
     * Sorts the list in non-decreasing order, per the given comparator
     * @param list       a list
     * @param comp  a comparator of the objects in the list
     */
    public void sort(ArrayList<T> mArray, Comparator<T> c) {
        int scanRange = mArray.size();
        T max;
        T temp;
        int maxl;
        
        for (int j=0; j<mArray.size(); j++) {
             //find the largest item in the unaltered range
            max = mArray.get(0);
            maxl = 0;
            
            for (int i=1; i<scanRange; i++) {
                if (c.compare(mArray.get(i),max)>0) {
                    maxl = i;
                    max = mArray.get(i);
                }
            }
            
            //swap it with the number to the left of the scan range and make that a part of the non-scan range
            scanRange--;
            temp = mArray.get(scanRange);
            mArray.set(scanRange,mArray.get(maxl));
            mArray.set(maxl,temp);
        }
    }
}
