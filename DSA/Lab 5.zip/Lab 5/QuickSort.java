import java.util.ArrayList;
import java.util.Comparator;
import java.util.Random;

/**
 * This will sort an arraylist based on the quicksort algorithm
 * 
 * @author Brandon Dixon
 * @version 2/9/15
 */
public class QuickSort<T> implements Sorter<T>
{
    /**
     * Sorts the list in non-decreasing order, per the given comparator
     * @param list       a list
     * @param comp  a comparator of the objects in the list
     */
    public void sort(ArrayList<T> mArray, Comparator<T> c) {
        sortRecursive(mArray,c,0,mArray.size()-1);
    }

    private void sortRecursive(ArrayList<T> mArray, Comparator<T> c, int s, int e) {
        if (s < e-1) {  //if there are at least two values to be sorted
            Random rand = new Random();
            int p = rand.nextInt(mArray.size());
            //int endl; p is endl
            //int startr; p+1 is startr

            //rearrange the values in mArray and set the endleft and startright values
            p = partition(mArray, c,p,p,p+1);

            testPrintString(mArray);
            System.out.println(mArray.size());

            sortRecursive(mArray, c,0,p);
            sortRecursive(mArray,c, p+1,mArray.size()-1);
        }
    }

    private int partition(ArrayList<T> mArray, Comparator<T> c, int p, int endl, int startr) {
        for (int i=0; i<mArray.size(); i++) {
            if (i<p) {
                if (c.compare(mArray.get(i),mArray.get(p))>0)  {                   
                    mArray.add(mArray.get(i));
                    mArray.remove(i);
                    p=i;
                }
            } else if (i>p) {
                if (c.compare(mArray.get(i),mArray.get(p))<0) {
                    mArray.add(0,mArray.get(i));
                    mArray.remove(i+1);
                    p=i;
                }
            }
        }
        return p;
    }

    private void testPrintString(ArrayList<T> mArray) {
        for (int i=0; i<mArray.size(); i++) {
            System.out.print(mArray.get(i)+ "  ");
        }
        System.out.println();
    }
}
